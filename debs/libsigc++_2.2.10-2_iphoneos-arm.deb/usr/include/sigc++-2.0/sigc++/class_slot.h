// -*- c++ -*-
/* Do not edit! -- generated file */


#ifndef _SIGC_MACROS_CLASS_SLOTHM4_
#define _SIGC_MACROS_CLASS_SLOTHM4_

#include <sigc++/slot.h>
#include <sigc++/functors/mem_fun.h>

#endif /* _SIGC_MACROS_CLASS_SLOTHM4_ */
