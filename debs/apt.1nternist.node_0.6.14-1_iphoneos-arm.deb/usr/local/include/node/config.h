/* Configuration header created by Waf - do not edit */
#ifndef _CONFIG_H_WAF
#define _CONFIG_H_WAF

#define HAVE_SSL_LIBRARY_INIT 1
#define HAVE_OPENSSL_CRYPTO_H 1
#define HAVE_CONFIG_H 1
#endif /* _CONFIG_H_WAF */
