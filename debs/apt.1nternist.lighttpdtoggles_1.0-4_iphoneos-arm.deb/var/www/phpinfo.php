<div align=center>Note: If you don't see anything below, it means PHP is not installed.<br>
You can find php package in Cydia and install it.<br>
Then you can use/build/run powerful PHP projects on your iPhone.<br>
Below you should see PHP INFO: <br><br> </div>
<?
phpinfo();	
?>
