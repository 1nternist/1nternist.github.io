// -*- c++ -*-
/* Do not edit! -- generated file */


#ifndef _SIGC_MACROS_SLOTHM4_
#define _SIGC_MACROS_SLOTHM4_

#include <sigc++/functors/slot.h>
#endif /* _SIGC_MACROS_SLOTHM4_ */
